/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medactema14.practica_intermodular;

/**
 *
 * @author Usuario
 */
public class Satelites {
   String  nombre ;
   Planetas planeta;
   float radio;
   float temperatura;
   float distancia_media;
   String  tipo_cuerpo;
   String fecha_creacion;

    public Satelites(String nombre, Planetas planeta, float radio, float temperatura, float distancia_media, String tipo_cuerpo, String fecha_creacion) {
        this.nombre = nombre;
        this.planeta = planeta;
        this.radio = radio;
        this.temperatura = temperatura;
        this.distancia_media = distancia_media;
        this.tipo_cuerpo = tipo_cuerpo;
        this.fecha_creacion = fecha_creacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Planetas getPlaneta() {
        return planeta;
    }

    public void setPlaneta(Planetas planeta) {
        this.planeta = planeta;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public float getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(float temperatura) {
        this.temperatura = temperatura;
    }

    public float getDistancia_media() {
        return distancia_media;
    }

    public void setDistancia_media(float distancia_media) {
        this.distancia_media = distancia_media;
    }

    public String getTipo_cuerpo() {
        return tipo_cuerpo;
    }

    public void setTipo_cuerpo(String tipo_cuerpo) {
        this.tipo_cuerpo = tipo_cuerpo;
    }

    public String getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(String fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }
   
    
    
}
