/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medactema14.practica_intermodular;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Usuario
 */
public class conectividad {


// Configuración de la conexión a la base de datos MySQL
        String url = "jdbc:mysql://localhost:3306/practica_intermodular";
        String usuario = "root";
        String contraseña = "Med@c";
        
// Sentencias SQL

        String pMercurio="Select * from Planeta where nombre = '";
        String estrellaconsulta="select * from estrella";

       
        
        //metodos

    public String[] conectarYconsultarMercurio(String planeta) {
        //1.crear array
        String[] datosMercurio = new String[8];
        //2.CONECTAR
        try{
            pMercurio+=planeta + "'"; 
        Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
        Statement statement = conexion.createStatement();
        // 3.lanzar query
        ResultSet resultados = statement.executeQuery(pMercurio);
        //4.recoger datos y guardar en array
          while (resultados.next()) {
// Obtener los valores de las columnas
                datosMercurio[0] = resultados.getString("radio");
                datosMercurio[1] = resultados.getString("distancia");
                datosMercurio[2] = resultados.getString("periodo_orbitario");
                datosMercurio[3] = resultados.getString("temperatura");
                datosMercurio[4] = resultados.getString("tipo");
                datosMercurio[5] = resultados.getString("fecha_creacion");
                datosMercurio[6] = resultados.getString("num_satelites");
          }
           //5.cerrar
         statement.close();
         conexion.close();
        }catch (SQLException e) {
            e.printStackTrace();
        }
      
        //6.retur array
            return datosMercurio;
    }
    public String[] conectarEstrella(){
        
        String[] estrella = new String[7];
        try{
            Connection conexion = DriverManager.getConnection(url,usuario,contraseña);
            Statement statement = conexion.createStatement();
            ResultSet resultados = statement.executeQuery(estrellaconsulta);
            while (resultados.next()) {
                estrella[0] = resultados.getString("tipo");
                estrella[1] = resultados.getString("radio");
                estrella[2] = resultados.getString("temperatura");
                estrella[3] = resultados.getString("distancia");
                estrella[4] = resultados.getString("composicion");
                estrella[5] = resultados.getString("fecha_creacion");
                
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return estrella;
    }
}

