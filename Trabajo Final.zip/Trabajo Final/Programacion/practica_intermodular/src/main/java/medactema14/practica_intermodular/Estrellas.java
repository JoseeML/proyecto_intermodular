/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medactema14.practica_intermodular;

/**
 *
 * @author Usuario
 */
public class Estrellas {

    String nombre;
    String tipo_estrella;
    float radio;
    float temperatura;
    float distancia_media;
    String composicion;
    String fecha_creacion;

    public Estrellas(String nombre, String tipo_estrella, float radio, float temperatura, float distancia_media, String composicion, String fecha_creacion) {
        this.nombre = nombre;
        this.tipo_estrella = tipo_estrella;
        this.radio = radio;
        this.temperatura = temperatura;
        this.distancia_media = distancia_media;
        this.composicion = composicion;
        this.fecha_creacion = fecha_creacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo_estrella() {
        return tipo_estrella;
    }

    public void setTipo_estrella(String tipo_estrella) {
        this.tipo_estrella = tipo_estrella;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public float getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(float temperatura) {
        this.temperatura = temperatura;
    }

    public float getDistancia_media() {
        return distancia_media;
    }

    public void setDistancia_media(float distancia_media) {
        this.distancia_media = distancia_media;
    }

    public String getComposicion() {
        return composicion;
    }

    public void setComposicion(String composicion) {
        this.composicion = composicion;
    }

    public String getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(String fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }
    
}
